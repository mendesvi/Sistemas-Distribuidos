import os
import queue
import random
import socket
import sys
import threading
import time

IP = "127.0.0.1"


def criarServidor(porta, sendQueue, vizinho):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((IP, porta))
        s.listen()
        conn, addr = s.accept()
        enviar = threading.Thread(
            target=enviarMsg, args=(conn, sendQueue))
        enviar.start()
        while True:
            data = str(conn.recv(1024).decode())
            if data == "Exit" or not data:
                conn.close()
                os._exit(1)
            readQueue.put(vizinho+data)


def criarCliente(porta, sendQueue, vizinho):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((IP, porta))
        enviar = threading.Thread(
            target=enviarMsg, args=(s, sendQueue))
        enviar.start()
        while True:
            data = str(s.recv(1024).decode())
            if data == "Exit":
                s.close()
                os._exit(1)
            readQueue.put(vizinho+data)


def enviarMsg(socket, sendQueue):
    while True:
        mensagem = sendQueue.get()
        socket.sendall(mensagem.encode())
        if mensagem == "Exit":
            socket.close()
            os._exit(1)


readQueue = queue.Queue[str]()

sendQueue1 = queue.Queue[str]()
sendQueue2 = queue.Queue[str]()
sendQueue3 = queue.Queue[str]()
sendQueue4 = queue.Queue[str]()

enderecosEnvio = queue.Queue[socket.socket]()

id = sys.argv[1]

porta1 = 0
porta2 = 0
porta3 = 0
porta4 = 0

if id == 'A':
    porta1 = 50000
    porta2 = 50001
elif id == 'B':
    porta1 = 50002
    porta3 = 50000
elif id == 'C':
    porta1 = 50003
    porta3 = 50001
    porta4 = 50002
elif id == 'D':
    porta1 = 50004
    porta2 = 50005
    porta3 = 50003
elif id == 'E':
    porta1 = 50006
    porta2 = 50007
    porta3 = 50004
elif id == 'F':
    porta1 = 50008
    porta2 = 50009
    porta3 = 50006
elif id == 'G':
    porta1 = 50010
    porta2 = 50011
    porta3 = 50007
    porta4 = 50008
elif id == 'H':
    porta1 = 50012
    porta3 = 50005
    porta4 = 50010
elif id == 'I':
    porta1 = 50013
    porta3 = 50011
    porta4 = 50012
elif id == 'J':
    porta3 = 50009
    porta4 = 50013


if porta1 != 0:
    sv1 = threading.Thread(target=criarServidor,
                           args=(porta1, sendQueue1, "1"))
    sv1.start()
if porta2 != 0:
    sv2 = threading.Thread(target=criarServidor,
                           args=(porta2, sendQueue2, "2"))
    sv2.start()
if porta3 != 0:
    cl1 = threading.Thread(target=criarCliente,
                           args=(porta3, sendQueue3, "3"))
    cl1.start()
if porta4 != 0:
    cl2 = threading.Thread(target=criarCliente,
                           args=(porta4, sendQueue4, "4"))
    cl2.start()

eleicao = False
lider = "Nenhum"
iniciei = False

vizinhos = ["0", "0", "0", "0"]
vizinhosId = ["", "", "", ""]

pai = "Z"
paiQueue = "0"
iniciadorEleicao = "Z"

idEleicao = id
eleicaoValor = 0

numRespostas = 0

meuValor = str(random.randint(1, 10000))

print("Meu id é " + id + " e meu valor é " + meuValor)


def pedirEleicao():
    print("1 Nova eleicao, 2 ver lider atual: ")
    while True:
        msg = input()
        if msg == "1":
            readQueue.put(id+"inicio")
        elif msg == "2":
            print("O lider atual é " + lider)


leitor = threading.Thread(target=pedirEleicao, args=())
leitor.start()


def fazerComparacao():
    maior = meuValor
    maiorID = id

    if porta1 != 0 and "1" != paiQueue:
        if int(vizinhos[0]) >= int(maior):
            maior = vizinhos[0]
            maiorID = vizinhosId[0]
    if porta2 != 0 and "2" != paiQueue:
        if int(vizinhos[1]) >= int(maior):
            maior = vizinhos[1]
            maiorID = vizinhosId[1]
    if porta3 != 0 and "3" != paiQueue:
        if int(vizinhos[2]) >= int(maior):
            maior = vizinhos[2]
            maiorID = vizinhosId[2]
    if porta4 != 0 and "4" != paiQueue:
        if int(vizinhos[3]) >= int(maior):
            maior = vizinhos[3]
            maiorID = vizinhosId[3]

    print("\n-----------Comparando retornos------------")
    print("Meu id: " + id+" Valor: " + meuValor)
    print("id do maior retornado: "+vizinhosId[0]+" Valor: "+vizinhos[0])
    print("id do maior retornado: "+vizinhosId[1]+" Valor: "+vizinhos[1])
    print("id do maior retornado: "+vizinhosId[2]+" Valor: "+vizinhos[2])
    print("id do maior retornado: "+vizinhosId[3]+" Valor: "+vizinhos[3])
    print("Id de maior valor: " + maiorID + " Valor: " + maior)
    print("---------Fim Comparacao---------\n")

    if not pai == "Z":
        if paiQueue == "1":
            sendQueue1.put(id+maiorID+"resposta"+maior)
        elif paiQueue == "2":
            sendQueue2.put(id+maiorID+"resposta"+maior)
        elif paiQueue == "3":
            sendQueue3.put(id+maiorID+"resposta"+maior)
        elif paiQueue == "4":
            sendQueue4.put(id+maiorID+"resposta"+maior)
        return "Z"
    else:
        if porta1 != 0:
            sendQueue1.put(id+maiorID+"novoLider")
        if porta2 != 0:
            sendQueue2.put(id+maiorID+"novoLider")
        if porta3 != 0:
            sendQueue3.put(id+maiorID+"novoLider")
        if porta4 != 0:
            sendQueue4.put(id+maiorID+"novoLider")
        readQueue.put("0"+id+maiorID+"novoLider")
        return lider


time.sleep(15)
while True:
    print()
    msg = readQueue.get()
    # msg para iniciar a eleicao
    # msg no formato: "inicio"
    print("Mensagem recebida: " + msg)
    if msg[1:] == "inicio":
        print("Iniciando nova eleicao")
        lider = "Nenhum"
        pai = "Z"
        paiQueue = "0"
        eleicaoValor = 0

        if not eleicao:
            iniciei = True
            eleicao = True
            if porta1 != 0:
                sendQueue1.put(id+id+"eleicao"+meuValor)
            else:
                numRespostas += 1
            if porta2 != 0:
                sendQueue2.put(id+id+"eleicao"+meuValor)
            else:
                numRespostas += 1
            if porta3 != 0:
                sendQueue3.put(id+id+"eleicao"+meuValor)
            else:
                numRespostas += 1
            if porta4 != 0:
                sendQueue4.put(id+id+"eleicao"+meuValor)
            else:
                numRespostas += 1

            if numRespostas == 4:
                print("Comparando valores retornados")
                retorno = fazerComparacao()
                if retorno != "Z":
                    print("Lider decidido")
                    lider = retorno
                    eleicao = False
                    vizinhos = ["0", "0", "0", "0"]
                    vizinhosId = ["", "", "", ""]
                    numRespostas = 0
                    meuValor = str(random.randint(1, 10000))

    # msg de eleicao
    # msg no formato: idQueueReceive(1 char) + idSender(1 char) + idInicadorEleicap(1 char) + "eleicao" + valInicEleicao # noqa: E501
    if msg[3:10] == "eleicao":

        idQueueReceiveMsg = msg[0:1]
        idSenderMsg = msg[1:2]
        idInicadorEleicaoMsg = msg[2:3]
        valInicEleicaoMsg = msg[10:]

        if eleicao is True and iniciadorEleicao == msg[2:3]:
            print("Recebeu um segundo pedido de eleicao do mesmo inciador")
            if idQueueReceiveMsg == "1":
                sendQueue1.put(id+"presente")
                vizinhos[0] = "0"
            if idQueueReceiveMsg == "2":
                sendQueue2.put(id+"presente")
                vizinhos[1] = "0"
            if idQueueReceiveMsg == "3":
                sendQueue3.put(id+"presente")
                vizinhos[2] = "0"
            if idQueueReceiveMsg == "4":
                sendQueue4.put(id+"presente")
                vizinhos[3] = "0"
        else:
            valor = msg[10:]
            mandarMsg = True

            if eleicao is True:
                print("Recebeu segundo pedido de eleicao de valor diferente")
                if int(valor) == eleicaoValor:
                    if idInicadorEleicaoMsg > iniciadorEleicao:
                        print("Id da nova eleicao maior, mudando de eleicao")
                        pai = idSenderMsg
                        paiQueue = idQueueReceiveMsg
                        eleicaoValor = int(valInicEleicaoMsg)
                        iniciadorEleicao = idInicadorEleicaoMsg
                        numRespostas = 0
                elif int(valor) > eleicaoValor:
                    print("Id da nova eleicao maior, mudando de eleicao")
                    pai = idSenderMsg
                    paiQueue = idQueueReceiveMsg
                    eleicaoValor = int(valInicEleicaoMsg)
                    iniciadorEleicao = idInicadorEleicaoMsg
                    numRespostas = 0
                else:
                    print("Id nova eleicao menor mandando ack")
                    if idQueueReceiveMsg == "1":
                        sendQueue1.put(id+"ack")
                    if idQueueReceiveMsg == "2":
                        sendQueue2.put(id+"ack")
                    if idQueueReceiveMsg == "3":
                        sendQueue3.put(id+"ack")
                    if idQueueReceiveMsg == "4":
                        sendQueue4.put(id+"ack")
                    mandarMsg = False
            else:
                print("Entrando na eleicao")
                pai = idSenderMsg
                paiQueue = idQueueReceiveMsg
                eleicaoValor = int(valInicEleicaoMsg)
                iniciadorEleicao = idInicadorEleicaoMsg
                numRespostas = 0
                eleicao = True

            if mandarMsg:
                if porta1 != 0 and "1" != paiQueue:
                    sendQueue1.put(id+iniciadorEleicao +
                                   "eleicao"+str(eleicaoValor))
                else:
                    numRespostas += 1

                if porta2 != 0 and "2" != paiQueue:
                    sendQueue2.put(id+iniciadorEleicao +
                                   "eleicao"+str(eleicaoValor))
                else:
                    numRespostas += 1

                if porta3 != 0 and "3" != paiQueue:
                    sendQueue3.put(id+iniciadorEleicao +
                                   "eleicao"+str(eleicaoValor))
                else:
                    numRespostas += 1

                if porta4 != 0 and "4" != paiQueue:
                    sendQueue4.put(id+iniciadorEleicao +
                                   "eleicao"+str(eleicaoValor))
                else:
                    numRespostas += 1

                # verifica o maior valor e decide o lider se for que iniciou a eleicao # noqa: E501
                if numRespostas == 4:
                    print("Comparando valores retornados")
                    retorno = fazerComparacao()
                    if retorno != "Z":
                        print("Lider decidido")
                        lider = retorno
                        eleicao = False
                        vizinhos = ["0", "0", "0", "0"]
                        vizinhosId = ["", "", "", ""]
                        numRespostas = 0
                        meuValor = str(random.randint(1, 10000))

    # msg de resposta para dizer que ja esta na fila(faz parte da arvore por outra conexão) # noqa: E501
    # msg no formato idQueueSender(1 char) + idSender(1 char) + "presente"
    elif msg[2:] == "presente":
        print("Resposta do vizinho recebida, nó ja na eleicao")
        idQueueSender = msg[0:1]
        numRespostas += 1
        vizinhos[int(idQueueSender)-1] = "0"
        if numRespostas == 4:
            print("Comparando valores retornados")
            retorno = fazerComparacao()
            if retorno != "Z":
                print("Lider decidido")
                lider = retorno
                vizinhos = ["0", "0", "0", "0"]
                vizinhosId = ["", "", "", ""]
                numRespostas = 0
                eleicao = False
                meuValor = str(random.randint(1, 10000))

    # msg de resposta quando outro no ja esta em reunião de id maior
    # msg no formato: idQueueSender(1 char) + idSender(1 char) + "ack"
    elif msg[2:] == "ack":
        print("Resposta do vizinho em outra eleicao de valor maior, faz nada")

    # msg de respsta do filho ao pai
    # msg no formato: idQueueRecebida(1 char) + idSender(1 char) + idMaiorResposta(1 char) + "resposta" + valorMaiorResposta(int) # noqa: E501
    elif msg[3:11] == "resposta":
        print("Reposta dos vizinhos filhos com o maior valor até então")
        idQueueReceiveMsg = msg[0:1]
        valorMaiorMsg = msg[11:]
        idMaiorRespostaMsg = msg[2:3]
        numRespostas += 1
        if idQueueReceiveMsg == "1":
            vizinhos[0] = valorMaiorMsg
            vizinhosId[0] = idMaiorRespostaMsg
        if idQueueReceiveMsg == "2":
            vizinhos[1] = valorMaiorMsg
            vizinhosId[1] = idMaiorRespostaMsg
        if idQueueReceiveMsg == "3":
            vizinhos[2] = valorMaiorMsg
            vizinhosId[2] = idMaiorRespostaMsg
        if idQueueReceiveMsg == "4":
            vizinhos[3] = valorMaiorMsg
            vizinhosId[3] = idMaiorRespostaMsg

        if numRespostas == 4:
            print("Comparando valores retornados")
            retorno = fazerComparacao()
            if retorno != "Z":
                print("Lider decidido")
                lider = retorno
                vizinhos = ["0", "0", "0", "0"]
                vizinhosId = ["", "", "", ""]
                numRespostas = 0
                eleicao = False
                meuValor = str(random.randint(1, 10000))

    # msg que informa o novo lider
    # msg no formato: idQueueRecebida(1 char) + idSender(1 char) + idLider(1 char) + "novoLider" # noqa : E501
    elif msg[3:] == "novoLider":
        lider = msg[2:3]

        if eleicao is True:
            print("Novo lider decidido")
            eleicao = False
            numRespostas = 0
            vizinhos = ["0", "0", "0", "0"]
            vizinhosId = ["", "", "", ""]
            meuValor = str(random.randint(1, 10000))
            if porta1 != 0 and paiQueue != "1":
                sendQueue1.put(id+lider+"novoLider")
            if porta2 != 0 and paiQueue != "2":
                sendQueue2.put(id+lider+"novoLider")
            if porta3 != 0 and paiQueue != "3":
                sendQueue3.put(id+lider+"novoLider")
            if porta4 != 0 and paiQueue != "4":
                sendQueue4.put(id+lider+"novoLider")
