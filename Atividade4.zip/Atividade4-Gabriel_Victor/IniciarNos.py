import subprocess

subprocess.Popen('python Atividade4.py A',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py B',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py C',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py D',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py E',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py F',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py G',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py H',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py I',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
subprocess.Popen('python Atividade4.py J',
                 creationflags=subprocess.CREATE_NEW_CONSOLE)
