/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicasttotord;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabriel e victor
 */
public class MulticastTotOrd {

    static class Mensagem {

        public String mensagem = "";
        public int timeStamp = 0;
        public int ack = 0;
    }

    static class TimeStamp {

        public int mTimeStamp;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe se � o processo 1, 2 ou 3");
        int idProcesso = scanner.nextInt();
        int portas1;
        int portas2;
        int portac1;
        int portac2;

        TimeStamp ts = new TimeStamp();

        switch (idProcesso) {
            case 1:
                portas1 = 50000;
                portas2 = 50001;
                portac1 = 51000;
                portac2 = 52000;
                break;
            case 2:
                portas1 = 51000;
                portas2 = 51001;
                portac1 = 50000;
                portac2 = 52001;
                break;
            case 3:
                portas1 = 52000;
                portas2 = 52001;
                portac1 = 50001;
                portac2 = 51001;
                break;
            default:
                return;
        }

        ts.mTimeStamp = idProcesso - 1;

        //fila para as msgs
        List<Mensagem> mensagens = new ArrayList<Mensagem>();
        //fila para os acks que precisam ser enviados
        BlockingQueue<Integer> acks = new LinkedBlockingQueue<Integer>();

        //Thread do servidor
        Thread Servidor1 = new Thread(new Runnable() {
            @Override
            public void run() {
                String texto = "";
                try {
                    ServerSocket servidor = new ServerSocket(portas1);
                    Socket socketServidor = servidor.accept();

                    ObjectOutputStream saida = new ObjectOutputStream(socketServidor.getOutputStream());
                    ObjectInputStream entrada = new ObjectInputStream(socketServidor.getInputStream());

//                    try {
//                        Thread.sleep(25000);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
//                    }
                    do {
                        byte[] mensagem = (byte[]) entrada.readObject();
                        byte[] textoByte = new byte[mensagem.length - 8];
                        byte[] byteTime = new byte[4];
                        byte[] byteExtra = new byte[4];

                        System.arraycopy(mensagem, 0, textoByte, 0, mensagem.length - 8);
                        texto = new String(textoByte, StandardCharsets.UTF_8);

                        System.arraycopy(mensagem, textoByte.length, byteTime, 0, 4);
                        System.arraycopy(mensagem, textoByte.length + 4, byteExtra, 0, 4);

                        int mTimestampNew = ByteBuffer.wrap(byteTime).getInt();

                        int extraData = ByteBuffer.wrap(byteExtra).getInt();
                        synchronized (mensagens) {
                            if ("ack".equals(texto)) {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < extraData) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if(aumentou == 1)
                                {
                                   ts.mTimeStamp = ts.mTimeStamp - 10;
                                }

                                int achouMsg = 0;
                                for (Mensagem msg : mensagens) {
                                    if (msg.timeStamp == mTimestampNew) {
                                        msg.ack += 1;
                                        achouMsg = 1;
                                    }
                                }
                                if (achouMsg == 0) {
                                    Mensagem msg = new Mensagem();
                                    msg.timeStamp = mTimestampNew;
                                    msg.ack += 1;

                                    int adicionou = 0;
                                    for (int i = 0; i < mensagens.size(); i++) {
                                        if (mensagens.get(i).timeStamp > msg.timeStamp) {
                                            mensagens.add(i, msg);
                                            adicionou = 1;
                                            break;
                                        }
                                    }
                                    if (adicionou == 0) {
                                        mensagens.add(msg);
                                    }
                                }
                            } else {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < mTimestampNew) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if(aumentou == 1)
                                {
                                   ts.mTimeStamp = ts.mTimeStamp - 10;
                                }
                                

                                int adicionou = 0;
                                for (int i = 0; i < mensagens.size(); i++) {
                                    if (mensagens.get(i).timeStamp == mTimestampNew) {
                                        mensagens.get(i).mensagem = texto;
                                        mensagens.get(i).ack += 1;
                                        adicionou = 1;
                                        break;
                                    } else if (mensagens.get(i).timeStamp > mTimestampNew) {
                                        Mensagem men = new Mensagem();
                                        men.timeStamp = mTimestampNew;
                                        men.mensagem = texto;
                                        men.ack += 1;
                                        mensagens.add(i, men);
                                        adicionou = 1;
                                        break;
                                    }
                                }
                                if (adicionou == 0) {
                                    Mensagem men = new Mensagem();
                                    men.timeStamp = mTimestampNew;
                                    men.mensagem = texto;
                                    men.ack += 1;
                                    mensagens.add(men);
                                }

                                acks.add(mTimestampNew);
                            }
                        }
                    } while (!"fim".equals(texto));
                    saida.close();
                    entrada.close();
                    socketServidor.close();
                    System.exit(0);
                } catch (IOException | ClassNotFoundException ex) {
                    System.out.println(ex);
                }
            }
        });
        Servidor1.start();

        //Thread do servidor
        Thread Servidor2 = new Thread(new Runnable() {
            @Override
            public void run() {
                String texto = "";
                try {
                    ServerSocket servidor = new ServerSocket(portas2);
                    Socket socketServidor = servidor.accept();

                    ObjectOutputStream saida = new ObjectOutputStream(socketServidor.getOutputStream());
                    ObjectInputStream entrada = new ObjectInputStream(socketServidor.getInputStream());

//                    try {
//                        Thread.sleep(25000);
//                    } catch (InterruptedException ex) {
//                        Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
//                    }
                    do {
                        byte[] mensagem = (byte[]) entrada.readObject();
                        byte[] textoByte = new byte[mensagem.length - 8];
                        byte[] byteTime = new byte[4];
                        byte[] byteExtra = new byte[4];

                        System.arraycopy(mensagem, 0, textoByte, 0, mensagem.length - 8);
                        texto = new String(textoByte, StandardCharsets.UTF_8);

                        System.arraycopy(mensagem, textoByte.length, byteTime, 0, 4);
                        System.arraycopy(mensagem, textoByte.length + 4, byteExtra, 0, 4);

                        int mTimestampNew = ByteBuffer.wrap(byteTime).getInt();

                        int extraData = ByteBuffer.wrap(byteExtra).getInt();
                        synchronized (mensagens) {
                            if ("ack".equals(texto)) {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < extraData) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if(aumentou == 1)
                                {
                                   ts.mTimeStamp = ts.mTimeStamp - 10;
                                }

                                int achouMsg = 0;
                                for (Mensagem msg : mensagens) {
                                    if (msg.timeStamp == mTimestampNew) {
                                        msg.ack += 1;
                                        achouMsg = 1;
                                    }
                                }
                                if (achouMsg == 0) {
                                    Mensagem msg = new Mensagem();
                                    msg.timeStamp = mTimestampNew;
                                    msg.ack += 1;

                                    int adicionou = 0;
                                    for (int i = 0; i < mensagens.size(); i++) {
                                        if (mensagens.get(i).timeStamp > msg.timeStamp) {
                                            mensagens.add(i, msg);
                                            adicionou = 1;
                                            break;
                                        }
                                    }
                                    if (adicionou == 0) {
                                        mensagens.add(msg);
                                    }
                                }
                            } else {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < mTimestampNew) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if(aumentou == 1)
                                {
                                   ts.mTimeStamp = ts.mTimeStamp - 10;
                                }
                                

                                int adicionou = 0;
                                for (int i = 0; i < mensagens.size(); i++) {
                                    if (mensagens.get(i).timeStamp == mTimestampNew) {
                                        mensagens.get(i).mensagem = texto;
                                        mensagens.get(i).ack += 1;
                                        adicionou = 1;
                                        break;
                                    } else if (mensagens.get(i).timeStamp > mTimestampNew) {
                                        Mensagem men = new Mensagem();
                                        men.timeStamp = mTimestampNew;
                                        men.mensagem = texto;
                                        men.ack += 1;
                                        mensagens.add(i, men);
                                        adicionou = 1;
                                        break;
                                    }
                                }
                                if (adicionou == 0) {
                                    Mensagem men = new Mensagem();
                                    men.timeStamp = mTimestampNew;
                                    men.mensagem = texto;
                                    men.ack += 1;
                                    mensagens.add(men);
                                }

                                acks.add(mTimestampNew);
                            }
                        }
                    } while (!"fim".equals(texto));
                    saida.close();
                    entrada.close();
                    socketServidor.close();
                    System.exit(0);
                } catch (IOException | ClassNotFoundException ex) {
                    System.out.println(ex);
                }
            }
        });
        Servidor2.start();

        int espera = 0;
        while (espera == 0) {
            System.out.println("Digite qualquer numero ap�s iniciar os outros servidores");
            espera = scanner.nextInt();
        }
        scanner.nextLine();

        try {
            Socket clienteSocket1 = new Socket("localhost", portac1);
            ObjectOutputStream saida1 = new ObjectOutputStream(clienteSocket1.getOutputStream());
            saida1.flush();
            ObjectInputStream entrada1 = new ObjectInputStream(clienteSocket1.getInputStream());

            Socket clienteSocket2 = new Socket("localhost", portac2);
            ObjectOutputStream saida2 = new ObjectOutputStream(clienteSocket2.getOutputStream());
            saida2.flush();
            ObjectInputStream entrada2 = new ObjectInputStream(clienteSocket2.getInputStream());

            //Thread que le a entrada e envia as msgs
            Thread Leitor1 = new Thread(new Runnable() {
                String texto = "";

                @Override
                public void run() {
                    do {
                        texto = scanner.nextLine();
                        byte[] byteArrray = texto.getBytes(StandardCharsets.UTF_8);;
                        if (texto.length() <= 50 && texto.length() >= 1) {
                            synchronized (mensagens) {
                                ts.mTimeStamp = ts.mTimeStamp + 10;
                                Mensagem men = new Mensagem();
                                men.timeStamp = ts.mTimeStamp;
                                men.mensagem = texto;

                                mensagens.add(men);

                                byte[] byteTimesTamp = ByteBuffer.allocate(4).putInt(ts.mTimeStamp).array();
                                byte[] byteIdSender = ByteBuffer.allocate(4).putInt(idProcesso).array();

                                byte[] mensagem = new byte[byteArrray.length + byteTimesTamp.length + byteIdSender.length];
                                System.arraycopy(byteArrray, 0, mensagem, 0, byteArrray.length);
                                System.arraycopy(byteTimesTamp, 0, mensagem, byteArrray.length, byteTimesTamp.length);
                                System.arraycopy(byteIdSender, 0, mensagem, byteArrray.length + byteTimesTamp.length, byteIdSender.length);
                                try {
                                    saida1.writeObject(mensagem);
                                    saida1.flush();
                                    saida2.writeObject(mensagem);
                                    saida2.flush();
                                } catch (IOException ex) {
                                    Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } else if (texto.length() == 0) {
                            System.out.println("Mensagem n�o enviada, digite alguma coisa");
                        } else {
                            System.out.println("Mensagem muito grande, max 50 char");
                        }
                    } while (!("fim").equals(texto));
                    try {
                        saida1.close();
                        entrada1.close();
                        clienteSocket1.close();
                        saida2.close();
                        entrada2.close();
                        clienteSocket2.close();
                    } catch (IOException ex) {
                        Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    System.exit(0);
                }
            });

            Leitor1.start();

            //Thread que envia acks
            Thread AckSender = new Thread(new Runnable() {
                @Override
                public void run() {
                    String ackTxt = "ack";
                    byte[] byteArrray = ackTxt.getBytes(StandardCharsets.UTF_8);;
                    while (true) {
                        try {
                            int ackSend = acks.take();

                            synchronized (mensagens) {

                                ts.mTimeStamp = ts.mTimeStamp + 10;

                                byte[] byteTimesTamp = ByteBuffer.allocate(4).putInt(ackSend).array();
                                byte[] ackTimestamp = ByteBuffer.allocate(4).putInt(ts.mTimeStamp).array();
                                byte[] mensagem = new byte[byteArrray.length + byteTimesTamp.length + ackTimestamp.length];
                                System.arraycopy(byteArrray, 0, mensagem, 0, byteArrray.length);
                                System.arraycopy(byteTimesTamp, 0, mensagem, byteArrray.length, byteTimesTamp.length);
                                System.arraycopy(ackTimestamp, 0, mensagem, byteArrray.length + byteTimesTamp.length, ackTimestamp.length);
                                try {
                                    saida1.writeObject(mensagem);
                                    saida1.flush();
                                    saida2.writeObject(mensagem);
                                    saida2.flush();
                                } catch (IOException ex) {
                                    Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } catch (InterruptedException ex) {
                            Logger.getLogger(MulticastTotOrd.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
            AckSender.start();

            //Checa o primeiro elemento da fila
            while (Leitor1.isAlive() || AckSender.isAlive()) {
                if (!mensagens.isEmpty() && mensagens.get(0) != null) {
                    Mensagem msg = mensagens.get(0);
                    if (msg.ack >= 2) {
                        synchronized (mensagens) {
                            System.out.println("Mensagem recebida por todos os membros:" + msg.mensagem + ", Timestamp:" + msg.timeStamp);
                            mensagens.remove(0);
                        }
                    }
                }
            }

            saida1.close();
            entrada1.close();
            clienteSocket1.close();
            saida2.close();
            entrada2.close();
            clienteSocket2.close();
        } catch (IOException ex) {
            System.out.println("sa" + ex);
        }
    }
}
