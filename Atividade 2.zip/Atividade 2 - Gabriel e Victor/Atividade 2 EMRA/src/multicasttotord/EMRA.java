/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicasttotord;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabriel e victor
 */
public class EMRA {

    static class Requisi��es {

        public int idProc;
        public String recurso = "Na";
        public int timeStamp = 0;
    }

    static class TimeStamp {

        public int mTimeStamp;
    }

    static class Oks {

        public int idProc;
        public String recurso;
    }

    /**
     * @param args the command line arguments
     */
    static String recursoExec = "Na";
    static String recursoEspera = "Na";
    static int OksRecebidos = 0;
    static BlockingQueue<Integer> recursoFim = new LinkedBlockingQueue<Integer>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe se � o processo 1, 2 ou 3");
        int idProcesso = scanner.nextInt();
        int portas1;
        int portas2;
        int portac1;
        int portac2;
        int processo1;
        int processo2;

        TimeStamp ts = new TimeStamp();

        switch (idProcesso) {
            case 1:
                portas1 = 50000;
                portas2 = 50001;
                portac1 = 51000;
                portac2 = 52000;
                processo1 = 2;
                processo2 = 3;
                break;
            case 2:
                portas1 = 51000;
                portas2 = 51001;
                portac1 = 50000;
                portac2 = 52001;
                processo1 = 1;
                processo2 = 3;
                break;
            case 3:
                portas1 = 52000;
                portas2 = 52001;
                portac1 = 50001;
                portac2 = 51001;
                processo1 = 1;
                processo2 = 2;
                break;
            default:
                return;
        }

        ts.mTimeStamp = idProcesso - 1;

        //fila para as msgs
        List<Requisi��es> requisi��es = new ArrayList<Requisi��es>();
        //fila para os acks que precisam ser enviados
        BlockingQueue<Oks> oks = new LinkedBlockingQueue<Oks>();
        BlockingQueue<String> rodarRecurso = new LinkedBlockingQueue<String>();

        //Thread do servidor
        Thread Servidor1 = new Thread(new Runnable() {
            @Override
            public void run() {
                String texto = "";
                try {
                    ServerSocket servidor = new ServerSocket(portas1);
                    Socket socketServidor = servidor.accept();

                    ObjectOutputStream saida = new ObjectOutputStream(socketServidor.getOutputStream());
                    ObjectInputStream entrada = new ObjectInputStream(socketServidor.getInputStream());

                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    do {
                        byte[] mensagem = (byte[]) entrada.readObject();
                        byte[] textoByte = new byte[mensagem.length - 8];
                        byte[] byteTime = new byte[4];
                        byte[] byteExtra = new byte[4];

                        System.arraycopy(mensagem, 0, textoByte, 0, mensagem.length - 8);
                        texto = new String(textoByte, StandardCharsets.UTF_8);

                        System.arraycopy(mensagem, textoByte.length, byteTime, 0, 4);
                        System.arraycopy(mensagem, textoByte.length + 4, byteExtra, 0, 4);

                        int mTimestampNew = ByteBuffer.wrap(byteTime).getInt();

                        int idProc = ByteBuffer.wrap(byteExtra).getInt();

                        synchronized (ts) {
                            if ("ok".equals(texto)) {
                                OksRecebidos += 1;
                                if (OksRecebidos >= 3) {
                                    rodarRecurso.add(recursoEspera);
                                }
                            } else {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < mTimestampNew) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if (aumentou == 1) {
                                    ts.mTimeStamp = ts.mTimeStamp - 10;
                                }
                                if (recursoEspera.equals(texto)) {
                                    int adicionou = 0;
                                    int naoOk = 0;
                                    for (int i = 0; i < requisi��es.size(); i++) {
                                        if (requisi��es.get(i).timeStamp > mTimestampNew) {
                                            Requisi��es req = new Requisi��es();
                                            req.timeStamp = mTimestampNew;
                                            req.recurso = texto;
                                            req.idProc = idProc;
                                            requisi��es.add(i, req);
                                            adicionou = 1;
                                            break;
                                        } else {
                                            if (requisi��es.get(i).recurso.equals(texto) && !recursoExec.equals(texto)) {
                                                if (requisi��es.get(i).idProc == idProcesso) {
                                                    naoOk = 1;
                                                }
                                            }
                                        }
                                    }
                                    if (adicionou == 0) {
                                        Requisi��es req = new Requisi��es();
                                        req.timeStamp = mTimestampNew;
                                        req.recurso = texto;
                                        req.idProc = idProc;
                                        requisi��es.add(req);
                                    }
                                    if (naoOk == 0 && !recursoExec.equals(texto)) {
                                        Oks ok = new Oks();
                                        ok.idProc = idProc;
                                        ok.recurso = texto;
                                        oks.add(ok);
                                    }
                                } else {
                                    Oks ok = new Oks();
                                    ok.idProc = idProc;
                                    ok.recurso = texto;
                                    oks.add(ok);
                                }
                            }
                        }

                    } while (!"fim".equals(texto));
                    saida.close();
                    entrada.close();
                    socketServidor.close();
                    System.exit(0);
                } catch (IOException | ClassNotFoundException ex) {
                    System.out.println(ex);
                }
            }
        }
        );
        Servidor1.start();

        //Thread do servidor
        Thread Servidor2 = new Thread(new Runnable() {
            @Override
            public void run() {
                String texto = "";
                try {
                    ServerSocket servidor = new ServerSocket(portas2);
                    Socket socketServidor = servidor.accept();

                    ObjectOutputStream saida = new ObjectOutputStream(socketServidor.getOutputStream());
                    ObjectInputStream entrada = new ObjectInputStream(socketServidor.getInputStream());

                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    do {
                        byte[] mensagem = (byte[]) entrada.readObject();
                        byte[] textoByte = new byte[mensagem.length - 8];
                        byte[] byteTime = new byte[4];
                        byte[] byteExtra = new byte[4];

                        System.arraycopy(mensagem, 0, textoByte, 0, mensagem.length - 8);
                        texto = new String(textoByte, StandardCharsets.UTF_8);

                        System.arraycopy(mensagem, textoByte.length, byteTime, 0, 4);
                        System.arraycopy(mensagem, textoByte.length + 4, byteExtra, 0, 4);

                        int mTimestampNew = ByteBuffer.wrap(byteTime).getInt();

                        int idProc = ByteBuffer.wrap(byteExtra).getInt();

                        synchronized (ts) {
                            if ("ok".equals(texto)) {
                                OksRecebidos += 1;
                                if (OksRecebidos >= 3) {
                                    rodarRecurso.add(recursoEspera);
                                }
                            } else {
                                int aumentou = 0;
                                while ((ts.mTimeStamp) < mTimestampNew) {
                                    ts.mTimeStamp = ts.mTimeStamp + 10;
                                    aumentou = 1;
                                }
                                if (aumentou == 1) {
                                    ts.mTimeStamp = ts.mTimeStamp - 10;
                                }
                                if (recursoEspera.equals(texto)) {
                                    int adicionou = 0;
                                    int naoOk = 0;
                                    for (int i = 0; i < requisi��es.size(); i++) {
                                        if (requisi��es.get(i).timeStamp > mTimestampNew) {
                                            Requisi��es req = new Requisi��es();
                                            req.timeStamp = mTimestampNew;
                                            req.recurso = texto;
                                            req.idProc = idProc;
                                            requisi��es.add(i, req);
                                            adicionou = 1;
                                            break;
                                        } else {
                                            if (requisi��es.get(i).recurso.equals(texto) && !recursoExec.equals(texto)) {
                                                if (requisi��es.get(i).idProc == idProcesso) {
                                                    naoOk = 1;
                                                }
                                            }
                                        }
                                    }
                                    if (adicionou == 0) {
                                        Requisi��es req = new Requisi��es();
                                        req.timeStamp = mTimestampNew;
                                        req.recurso = texto;
                                        req.idProc = idProc;
                                        requisi��es.add(req);
                                    }
                                    if (naoOk == 0 && !recursoExec.equals(texto)) {
                                        Oks ok = new Oks();
                                        ok.idProc = idProc;
                                        ok.recurso = texto;
                                        oks.add(ok);
                                    }
                                } else {
                                    Oks ok = new Oks();
                                    ok.idProc = idProc;
                                    ok.recurso = texto;
                                    oks.add(ok);
                                }
                            }
                        }

                    } while (!"fim".equals(texto));
                    saida.close();
                    entrada.close();
                    socketServidor.close();
                    System.exit(0);
                } catch (IOException | ClassNotFoundException ex) {
                    System.out.println(ex);
                }
            }
        });

        Servidor2.start();

        int espera = 0;
        while (espera
                == 0) {
            System.out.println("Digite qualquer numero ap�s iniciar os outros servidores");
            espera = scanner.nextInt();
        }

        scanner.nextLine();

        try {
            Socket clienteSocket1 = new Socket("localhost", portac1);
            ObjectOutputStream saida1 = new ObjectOutputStream(clienteSocket1.getOutputStream());
            saida1.flush();
            ObjectInputStream entrada1 = new ObjectInputStream(clienteSocket1.getInputStream());

            Socket clienteSocket2 = new Socket("localhost", portac2);
            ObjectOutputStream saida2 = new ObjectOutputStream(clienteSocket2.getOutputStream());
            saida2.flush();
            ObjectInputStream entrada2 = new ObjectInputStream(clienteSocket2.getInputStream());

            //Thread que le a entrada e envia as msgs
            Thread Leitor1 = new Thread(new Runnable() {
                String texto = "";

                @Override
                public void run() {
                    do {
                        texto = scanner.nextLine();
                        byte[] byteArrray = texto.getBytes(StandardCharsets.UTF_8);;
                        if (texto.length() <= 50 && texto.length() >= 1) {
                            synchronized (ts) {
                                ts.mTimeStamp = ts.mTimeStamp + 10;

                                Requisi��es req = new Requisi��es();
                                req.timeStamp = ts.mTimeStamp;
                                req.recurso = texto;
                                req.idProc = idProcesso;

                                recursoEspera = texto;
                                OksRecebidos = 1;

                                int adicionou = 0;
                                for (int i = 0; i < requisi��es.size(); i++) {
                                    if (requisi��es.get(i).timeStamp > req.timeStamp) {
                                        requisi��es.add(i, req);
                                        adicionou = 1;
                                        break;
                                    }
                                }
                                if (adicionou == 0) {
                                    requisi��es.add(req);
                                }

                                byte[] byteTimesTamp = ByteBuffer.allocate(4).putInt(ts.mTimeStamp).array();
                                byte[] byteIdSender = ByteBuffer.allocate(4).putInt(idProcesso).array();

                                byte[] mensagem = new byte[byteArrray.length + byteTimesTamp.length + byteIdSender.length];
                                System.arraycopy(byteArrray, 0, mensagem, 0, byteArrray.length);
                                System.arraycopy(byteTimesTamp, 0, mensagem, byteArrray.length, byteTimesTamp.length);
                                System.arraycopy(byteIdSender, 0, mensagem, byteArrray.length + byteTimesTamp.length, byteIdSender.length);
                                try {
                                    saida1.writeObject(mensagem);
                                    saida1.flush();
                                    saida2.writeObject(mensagem);
                                    saida2.flush();
                                    System.out.println("Esperando permiss�o para usar o recurso: " + texto + " Timestamp pedido: "+ ts.mTimeStamp);
                                } catch (IOException ex) {
                                    Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                            try {
                                if (!texto.equals("fim")) {
                                    recursoFim.take();
                                }
                            } catch (InterruptedException ex) {
                                Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        } else if (texto.length() == 0) {
                            System.out.println("Mensagem n�o enviada, digite alguma coisa");
                        } else {
                            System.out.println("Mensagem muito grande, max 50 char");
                        }
                    } while (!("fim").equals(texto));
                    try {
                        saida1.close();
                        entrada1.close();
                        clienteSocket1.close();
                        saida2.close();
                        entrada2.close();
                        clienteSocket2.close();
                    } catch (IOException ex) {
                        Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    System.exit(0);
                }
            });
            try {
                Thread.sleep(20000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
            }
            Leitor1.start();

            //Thread que envia acks
            Thread OkSender = new Thread(new Runnable() {
                @Override
                public void run() {
                    String okTxt = "ok";
                    byte[] byteArrray = okTxt.getBytes(StandardCharsets.UTF_8);;
                    while (true) {
                        try {
                            Oks okSend = oks.take();

                            synchronized (ts) {

                                ts.mTimeStamp = ts.mTimeStamp + 10;

                                byte[] byteTimesTamp = ByteBuffer.allocate(4).putInt(ts.mTimeStamp).array();
                                byte[] idProcByte = ByteBuffer.allocate(4).putInt(idProcesso).array();

                                byte[] mensagem = new byte[byteArrray.length + byteTimesTamp.length + idProcByte.length];
                                System.arraycopy(byteArrray, 0, mensagem, 0, byteArrray.length);
                                System.arraycopy(byteTimesTamp, 0, mensagem, byteArrray.length, byteTimesTamp.length);
                                System.arraycopy(idProcByte, 0, mensagem, byteArrray.length + byteTimesTamp.length, idProcByte.length);
                                System.out.println("Permiss�o de uso do recurso: " + okSend.recurso + " enviado para: " + okSend.idProc + " Timestamp Ok: " + ts.mTimeStamp);
                                try {
                                    if (okSend.idProc == processo1) {
                                        saida1.writeObject(mensagem);
                                        saida1.flush();
                                    } else if (okSend.idProc == processo2) {
                                        saida2.writeObject(mensagem);
                                        saida2.flush();
                                    }
                                } catch (IOException ex) {
                                    Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } catch (InterruptedException ex) {
                            Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
            OkSender.start();

            while (true) {
                //Checa o primeiro elemento da fila
                try {
                    String recurso = rodarRecurso.take();
                    recursoExec = recurso;
                    System.out.println("Recurso: " + recurso + " sendo executado");
                    Thread.sleep(30000);
                    recursoFim.add(1);//avisa que terminou de usar o recurso
                } catch (InterruptedException ex) {
                    Logger.getLogger(EMRA.class.getName()).log(Level.SEVERE, null, ex);
                }
                synchronized (ts) {
                    for (int i = requisi��es.size() - 1; i >= 0; i--) {
                        if (requisi��es.get(i).recurso.equals(recursoEspera)) {
                            Requisi��es req = requisi��es.remove(i);
                            if (req.idProc != idProcesso) {
                                Oks ok = new Oks();
                                ok.idProc = req.idProc;
                                ok.recurso = req.recurso;
                                oks.add(ok);
                            }
                        }
                    }
                    recursoEspera = "Na";
                    OksRecebidos = 0;
                }
            }
//            saida1.close();
//            entrada1.close();
//            clienteSocket1.close();
//            saida2.close();
//            entrada2.close();
//            clienteSocket2.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
