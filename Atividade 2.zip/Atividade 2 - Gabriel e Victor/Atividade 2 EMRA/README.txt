1 - Starta os três processos. 
2 - Passa um número diferente para cada.
3 - Digite qualquer int para iniciar os clientes, em todas as janelas.
4 - Cada string a ser digitada é um nome de processo. Tem um tempo livre para enfileirar os pedidos, antes dos processos 
    iniciarem de vez.
