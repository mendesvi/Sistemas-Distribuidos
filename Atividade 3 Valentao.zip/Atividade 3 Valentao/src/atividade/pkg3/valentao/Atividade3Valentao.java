/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade.pkg3.valentao;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class Atividade3Valentao {

    /**
     * @param args the command line arguments
     */
    static Timer timerNovaCord;//usado nas elei�oes
    static Timer timerEsperaCord;//usado para saber se o cordenador est� vivo
    static Timer timerAvisarCord;//usado para mandar novamente a mensagem avisando que eu(o cordenador) estou vivo
    static BlockingQueue<String> acao = new LinkedBlockingQueue<String>(); // a��o que o processo vai tomar a seguir
    static int idCordenador;//id do cordenador atual
    static int idProcesso;//id do processo

    public static void main(String[] args) {
        timerNovaCord = new Timer(); //tempo que cada coordenador fica no cargo
        timerEsperaCord = new Timer(); //tempo de resposta do coordenador
        timerAvisarCord = new Timer(); //

        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe se � o processo 1, 2, 3, 4 ou 5");
        idProcesso = scanner.nextInt();

        List<Integer> portaS = new ArrayList<Integer>(); //servidor
        List<Integer> portaC = new ArrayList<Integer>(); //cliente

        switch (idProcesso) {
            case 1:
                for (int i = 0; i < 5; i++) {
                    if (i != 0) {
                        portaS.add(50000 + i);//50001, 50002, 50003, 50004 | pula 50000
                        portaC.add(50000 + i * 1000);//51000, 52000, 53000, 54000  | pula 50000

                    }
                }
                break;
            case 2:
                for (int i = 0; i < 5; i++) {
                    if (i != 1) {
                        portaS.add(51000 + i);//51000, 51002, 51003, 51004 | pula 51001
                        portaC.add(50000 + i * 1000 + 1);//50001, 52001, 53001, 54001 | pula 51001
                    }
                }
                break;
            case 3:
                for (int i = 0; i < 5; i++) {
                    if (i != 2) {
                        portaS.add(52000 + i);//52000, 52001, 52003, 52004 | pula 52002
                        portaC.add(50000 + i * 1000 + 2);//50002, 51002, 53002, 54002 | pula 52002
                    }
                }
                break;
            case 4:
                for (int i = 0; i < 5; i++) {
                    if (i != 3) {
                        portaS.add(53000 + i);//53000, 53001, 53002, 53004 | pula 53003
                        portaC.add(50000 + i * 1000 + 3);//50003, 51003, 52003, 54003 | pula 53003
                    }
                }
                break;
            case 5:
                for (int i = 0; i < 5; i++) {
                    if (i != 4) {
                        portaS.add(54000 + i);//54000, 54001, 54002, 54003 | pula 54004
                        portaC.add(50000 + i * 1000 + 4);//50004, 51004, 52004, 53004 | pula 54004
                    }
                }
                break;
            default:
                return;
        }
        for (int i = 0; i < 4; i++) {
            //Thread do servidor
            final int porta = portaS.get(i);
            Thread Servidor = new Thread(new Runnable() {
                @Override
                public void run() {
                    Socket socketServidor = null;
                    ObjectOutputStream saida = null;
                    ObjectInputStream entrada = null;
                    try {
                        String texto = "";

                        ServerSocket servidor = new ServerSocket(porta);
                        socketServidor = servidor.accept();

                        saida = new ObjectOutputStream(socketServidor.getOutputStream());
                        entrada = new ObjectInputStream(socketServidor.getInputStream());
                        while (true) {

                            byte[] mensagem = (byte[]) entrada.readObject();

                            byte[] textoByte = new byte[mensagem.length - 4];
                            System.arraycopy(mensagem, 0, textoByte, 0, mensagem.length - 4);
                            texto = new String(textoByte, StandardCharsets.UTF_8);

                            byte[] byteIdProcesso = new byte[4];
                            System.arraycopy(mensagem, textoByte.length, byteIdProcesso, 0, 4);
                            int idProc = ByteBuffer.wrap(byteIdProcesso).getInt();

                            if (texto.equals("Eleicao")) {
                                if (idProc < idProcesso) {
                                    System.out.println("Nova elei��o iniciada por: " + idProc);
                                    acao.add("ResponderEleicao" + idProc);
                                    acao.add("IniciarEleicao");
                                    System.out.println("Meu id � maior iniciar nova eleicao");
                                } else {
                                    System.out.println("Nova elei��o iniciada por: " + idProc);
                                }
                            } else if (texto.equals("PararEleicao")) {
                                acao.add("PararEleicao");
                                timerNovaCord.cancel();
                                timerNovaCord = new Timer();
                                System.out.println("O processo: " + idProc + " de id maior mandou eu para minha eleicao");
                            } else if (texto.equals("NovoCord")) {
                                idCordenador = idProc;
                                timerEsperaCord.cancel();
                                timerEsperaCord = new Timer();
                                timerEsperaCord.schedule(new TimerCheckCordenador(), 10000);
                                System.out.println("Processo: " + idProc + " eleito");
                            } else if (texto.equals("Vivo")) {
                                if (idProc == idCordenador) {
                                    System.out.println("Cordenador de id: " + idProc + " vivo");
                                    timerEsperaCord.cancel();
                                    timerEsperaCord = new Timer();
                                    timerEsperaCord.schedule(new TimerCheckCordenador(), 10000);
                                } else {
                                    System.out.println("Mensagem eperado do cordenador: " + idCordenador + " mas enviada por: " + idProc);
                                    acao.add("IniciarEleicao");
                                    System.out.println("Iniciada nova eleicao");
                                }
                            } else if (texto.equals("fim")) {
                                saida.close();
                                entrada.close();
                                socketServidor.close();
                            }
                        }
                    } catch (IOException ex) {
                        try {
                            if (saida != null) {
                                saida.close();
                            }
                            if (saida != null) {
                                entrada.close();
                            }
                            if (saida != null) {
                                socketServidor.close();
                            }
                        } catch (IOException ex1) {
                            Logger.getLogger(Atividade3Valentao.class.getName()).log(Level.SEVERE, null, ex1);
                        }
                    } 
                    catch (ClassNotFoundException ex) {
                       
                    }

                }
            }
            );
            Servidor.start();

        }

        try {
            Thread.sleep(20000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Atividade3Valentao.class.getName()).log(Level.SEVERE, null, ex);
        }

        int j = 0;
        Cliente cli1 = null;
        Cliente cli2 = null;
        Cliente cli3 = null;
        Cliente cli4 = null;
        Cliente cli5 = null;
        if (idProcesso != 1) {
            cli1 = new Cliente(idProcesso, portaC.get(j));
            j++;
        }
        if (idProcesso != 2) {
            cli2 = new Cliente(idProcesso, portaC.get(j));
            j++;
        }
        if (idProcesso != 3) {
            cli3 = new Cliente(idProcesso, portaC.get(j));
            j++;
        }
        if (idProcesso != 4) {
            cli4 = new Cliente(idProcesso, portaC.get(j));
            j++;
        }
        if (idProcesso != 5) {
            cli5 = new Cliente(idProcesso, portaC.get(j));
            j++;
        }
        acao.add("IniciarEleicao");
        String acaoProcesso = "";
        while (true) {
            try {
                acaoProcesso = acao.take();
            } catch (InterruptedException ex) {
                Logger.getLogger(Atividade3Valentao.class.getName()).log(Level.SEVERE, null, ex);
            }
            switch (acaoProcesso) {
                case "ResponderEleicao1":
                    cli1.AdicionarMsg("PararEleicao");
                    break;
                case "ResponderEleicao2":
                    cli2.AdicionarMsg("PararEleicao");
                    break;
                case "ResponderEleicao3":
                    cli3.AdicionarMsg("PararEleicao");
                    break;
                case "ResponderEleicao4":
                    cli4.AdicionarMsg("PararEleicao");
                    break;
                case "ResponderEleicao5":
                    cli5.AdicionarMsg("PararEleicao");
                    break;
                case "IniciarEleicao":
                    switch (idProcesso) {
                        case 1:
                            cli2.AdicionarMsg("Eleicao");
                            cli3.AdicionarMsg("Eleicao");
                            cli4.AdicionarMsg("Eleicao");
                            cli5.AdicionarMsg("Eleicao");
                            timerNovaCord.cancel();
                            timerNovaCord = new Timer();
                            timerNovaCord.schedule(new TimerNewCord(), 10000);
                            break;
                        case 2:
                            cli3.AdicionarMsg("Eleicao");
                            cli4.AdicionarMsg("Eleicao");
                            cli5.AdicionarMsg("Eleicao");
                            timerNovaCord.cancel();
                            timerNovaCord = new Timer();
                            timerNovaCord.schedule(new TimerNewCord(), 10000);
                            break;
                        case 3:
                            cli4.AdicionarMsg("Eleicao");
                            cli5.AdicionarMsg("Eleicao");
                            timerNovaCord.cancel();
                            timerNovaCord = new Timer();
                            timerNovaCord.schedule(new TimerNewCord(), 10000);
                            break;
                        case 4:
                            cli5.AdicionarMsg("Eleicao");
                            timerNovaCord.cancel();
                            timerNovaCord = new Timer();
                            timerNovaCord.schedule(new TimerNewCord(), 10000);
                            break;
                        case 5:
                            timerNovaCord.cancel();
                            timerNovaCord = new Timer();
                            timerNovaCord.schedule(new TimerNewCord(), 10000);
                            break;
                    }
                    break;
                case "FuiEleito":
                    if (cli1 != null) {
                        cli1.AdicionarMsg("NovoCord");
                    }
                    if (cli2 != null) {
                        cli2.AdicionarMsg("NovoCord");
                    }
                    if (cli3 != null) {
                        cli3.AdicionarMsg("NovoCord");
                    }
                    if (cli4 != null) {
                        cli4.AdicionarMsg("NovoCord");
                    }
                    if (cli5 != null) {
                        cli5.AdicionarMsg("NovoCord");
                    }
                    break;
                case "Vivo":
                    if (cli1 != null) {
                        cli1.AdicionarMsg("Vivo");
                    }
                    if (cli2 != null) {
                        cli2.AdicionarMsg("Vivo");
                    }
                    if (cli3 != null) {
                        cli3.AdicionarMsg("Vivo");
                    }
                    if (cli4 != null) {
                        cli4.AdicionarMsg("Vivo");
                    }
                    if (cli5 != null) {
                        cli5.AdicionarMsg("Vivo");
                    }
                    break;
                case "PararEleicao":
                    timerNovaCord.cancel();
                    timerNovaCord = new Timer();
                    break;
            }
        }
    }

    static class TimerNewCord extends TimerTask {//timerNovaCord 

        public void run() {
            idCordenador = idProcesso;
            timerAvisarCord.cancel();
            timerAvisarCord = new Timer();
            timerAvisarCord.schedule(new TimerSendMensage(), 5000);
            System.out.println("Fui eleito");
            acao.add("FuiEleito");
            timerNovaCord.cancel(); //Terminate the timer thread
            timerNovaCord = new Timer();
        }
    }

    static class TimerSendMensage extends TimerTask {//timerAvisarCord 

        public void run() {
            timerAvisarCord.cancel();
            timerAvisarCord = new Timer();
            timerAvisarCord.schedule(new TimerSendMensage(), 5000);
            acao.add("Vivo");
        }
    }

    static class TimerCheckCordenador extends TimerTask {//timerEsperaCord

        public void run() {
            System.out.println("Cordenador de id: " + idCordenador + " parou de responder");
            System.out.println("Iniciar minha elei��o");
            idCordenador = 0;
            acao.add("IniciarEleicao");
            timerEsperaCord.cancel();
            timerEsperaCord = new Timer();
            timerEsperaCord.schedule(new TimerSendMensage(), 10000);
        }
    }
}
