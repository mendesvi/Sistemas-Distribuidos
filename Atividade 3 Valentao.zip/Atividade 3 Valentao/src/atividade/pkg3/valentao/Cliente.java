/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade.pkg3.valentao;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class Cliente {

    BlockingQueue<String> tipoMsg = new LinkedBlockingQueue<String>();

    Cliente(int idProcesso, int porta) {
        try {
            Socket clienteSocket = new Socket("localhost", porta);
            ObjectOutputStream saida = new ObjectOutputStream(clienteSocket.getOutputStream());
            saida.flush();
            ObjectInputStream entrada = new ObjectInputStream(clienteSocket.getInputStream());

            //Thread que le a entrada e envia as msgs
            Thread Leitor = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        String msg = "";
                        try {
                            msg = tipoMsg.take();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        try {
                            byte[] byteArrray = msg.getBytes(StandardCharsets.UTF_8);
                            byte[] byteIdProcess = ByteBuffer.allocate(4).putInt(idProcesso).array();
                            byte[] mensagem = new byte[byteArrray.length + byteIdProcess.length];
                            System.arraycopy(byteArrray, 0, mensagem, 0, byteArrray.length);
                            System.arraycopy(byteIdProcess, 0, mensagem, byteArrray.length, byteIdProcess.length);
                            saida.writeObject(mensagem);
                            saida.flush();
                        } catch (IOException ex) {
                            break;
                        }
                        if (msg.equals("fim")) {
                            try {
                                saida.close();

                                entrada.close();
                                clienteSocket.close();
                            } catch (IOException ex) {
                                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            });
            Leitor.start();

        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void AdicionarMsg(String msg) {
        tipoMsg.add(msg);
    }
}
